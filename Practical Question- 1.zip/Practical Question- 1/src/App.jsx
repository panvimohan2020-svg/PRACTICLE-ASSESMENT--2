import React from "react";

// Student functional component
function Student(props) {
  return (
    <div>
      <h2>Student Profile</h2>
      <p><strong>Name:</strong> {props.name}</p>
      <p><strong>Course:</strong> {props.course}</p>
      <p><strong>College:</strong> {props.college}</p>
      <hr />
    </div>
  );
}

function App() {
  return (
    <div>
      <h1>Student Profiles</h1>

      <Student
        name="Panvi Mohan"
        course="CSE-AIML"
        college="GIET University"
      />

      <Student
        name="Rahul Kumar"
        course="CSE"
        college="GIET University"
      />
    </div>
  );
}

export default App;